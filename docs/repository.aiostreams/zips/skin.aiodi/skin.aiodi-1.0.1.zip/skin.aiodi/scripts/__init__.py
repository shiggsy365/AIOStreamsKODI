"""
AIODI Skin Scripts Package
"""

"""
Helper script for custom information window.
Populates window properties with cast and related items data from database.
"""
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs
import sys
import os

# Add plugin path to sys.path
ADDON = xbmcaddon.Addon('plugin.video.aiostreams')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
sys.path.insert(0, os.path.join(ADDON_PATH, 'resources', 'lib'))

try:
    from addon import get_meta
except:
    get_meta = None


def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'[AIOStreams] [InfoWindowHelper] {msg}', level)


def populate_cast_properties():
    """
    Query database for cast data and set window properties.
    """
    try:
        # Get current item's IMDb ID and content type
        imdb_id = xbmc.getInfoLabel('ListItem.IMDBNumber')
        content_type = xbmc.getInfoLabel('ListItem.DBType')  # 'movie' or 'tvshow'
        
        if not imdb_id:
            log('No IMDb ID found', xbmc.LOGWARNING)
            return
        
        log(f'Fetching cast for {content_type}: {imdb_id}')
        
        # Get metadata from database
        if get_meta:
            meta_data = get_meta(content_type, imdb_id)
            if meta_data and 'meta' in meta_data:
                cast_list = meta_data['meta'].get('cast', [])
                
                # Get the current window
                window = xbmcgui.Window(xbmcgui.getCurrentWindowDialogId())
                
                # Set properties for up to 5 cast members
                for i in range(1, 6):
                    if i <= len(cast_list):
                        cast_member = cast_list[i-1]
                        name = cast_member.get('name', '')
                        role = cast_member.get('character', '')
                        thumb = cast_member.get('profile', '')
                        
                        window.setProperty(f'InfoWindow.Cast.{i}.Name', name)
                        window.setProperty(f'InfoWindow.Cast.{i}.Role', role)
                        window.setProperty(f'InfoWindow.Cast.{i}.Thumb', thumb)
                        log(f'Set cast {i}: {name} as {role}')
                    else:
                        # Clear properties if no more cast members
                        window.clearProperty(f'InfoWindow.Cast.{i}.Name')
                        window.clearProperty(f'InfoWindow.Cast.{i}.Role')
                        window.clearProperty(f'InfoWindow.Cast.{i}.Thumb')
                
                log(f'Cast properties populated: {len(cast_list)} members')
            else:
                log('No metadata found in database', xbmc.LOGWARNING)
        else:
            log('get_meta function not available', xbmc.LOGERROR)
        
    except Exception as e:
        log(f'Error populating cast properties: {e}', xbmc.LOGERROR)
        import traceback
        log(traceback.format_exc(), xbmc.LOGERROR)


if __name__ == '__main__':
    populate_cast_properties()

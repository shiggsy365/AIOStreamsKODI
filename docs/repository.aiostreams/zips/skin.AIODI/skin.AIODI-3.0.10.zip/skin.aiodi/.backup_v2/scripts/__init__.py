"""
AIODI Skin Scripts Package
"""

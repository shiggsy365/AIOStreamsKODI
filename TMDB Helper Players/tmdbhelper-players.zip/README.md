# AIOStreams TMDBHelper Player Files

These player files allow you to use AIOStreams with TMDBHelper addon for Kodi.

## Installation

### Option 1: Manual Installation

1. Copy the `.json` files to your Kodi userdata folder:
   ```
   <kodi_userdata>/addon_data/plugin.video.themoviedb.helper/players/
   ```

2. Restart Kodi or reload TMDBHelper

### Option 2: From TMDBHelper Settings

1. Open TMDBHelper Settings
2. Go to the "Players" tab
3. Select "Configure Players"
4. Click "+" to add a new player
5. Manually configure or import the JSON files

## Available Players

### aiostreams.direct.json
**Auto-play** - Automatically plays the first available stream from AIOStreams

- Priority: 100
- Use when: You want instant playback without stream selection
- Best for: Quick playback, library integration

### aiostreams.select.json  
**Source Select** - Shows a dialog to select from available streams

- Priority: 101
- Use when: You want to choose quality/source
- Best for: Manual quality selection, debugging

## Player Configuration

Both players support:
- **Movies**: Requires TMDB ID
- **TV Shows**: Requires TMDB ID, season number, and episode number

## How It Works

1. TMDBHelper passes media information (TMDB ID, season, episode) to the player
2. The player converts TMDB ID to the appropriate format for AIOStreams API
3. AIOStreams fetches available streams
4. Either auto-plays first stream or shows selection dialog
5. Stream URL is resolved and played in Kodi

## Troubleshooting

**No streams available:**
- Make sure AIOStreams is properly configured
- Check that your debrid services are set up in AIOStreams
- Verify the TMDB ID is correct

**Player not showing in TMDBHelper:**
- Check that JSON files are in the correct directory
- Restart Kodi
- Verify JSON syntax is valid

**Playback fails:**
- Check Kodi logs for errors
- Verify stream URLs are accessible
- Try the "Select" version to see available streams

## Media ID Format

AIOStreams uses these formats:
- **Movies**: `tmdb:12345`
- **TV Episodes**: `tmdb:12345:1:1` (tmdb_id:season:episode)

## Priority

Lower numbers = higher priority in TMDBHelper player selection dialog
- Direct play: 100
- Select: 101

You can adjust priority by editing the JSON files.

## Advanced Configuration

Edit the JSON files to:
- Change player names
- Adjust priority
- Add fallback players
- Customize assert conditions

See [TMDBHelper Wiki](https://github.com/jurialmunkey/plugin.video.themoviedb.helper/wiki/Player-Function) for more details.

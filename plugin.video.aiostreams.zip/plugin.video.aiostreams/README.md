# AIOStreams Kodi Addon

A Kodi addon for searching and streaming content from AIOStreams.

## Features

- Search movies via TMDB
- Search TV shows via TVDB
- Display available streams from AIOStreams
- Direct playback of streams
- **TMDBHelper Integration** - Use AIOStreams as a player in TMDBHelper

## Installation

1. Copy the `plugin.video.aiostreams` folder to your Kodi addons directory:
   - **Windows**: `%APPDATA%\Kodi\addons\`
   - **Linux**: `~/.kodi/addons/`
   - **Mac**: `~/Library/Application Support/Kodi/addons/`
   - **Android**: `/sdcard/Android/data/org.xbmc.kodi/files/.kodi/addons/`

2. Restart Kodi or go to Settings → Addons → Install from zip file

3. Enable the addon in Settings → Addons → My addons → Video addons

## Configuration

The addon comes pre-configured with your AIOStreams URL. If you need to change it:

1. Go to the addon settings
2. Update the "AIOStreams Base URL" field
3. Adjust the timeout if needed (default: 10 seconds)

## Usage

### Standalone Mode

1. Open the addon from Video Addons
2. Select "Search Movies" or "Search TV Shows"
3. Enter your search query
4. Select a result to view available streams
5. Select a stream to play

### TMDBHelper Integration

AIOStreams can be used as a player with TMDBHelper:

1. Copy player files from `tmdbhelper-players/` to:
   ```
   <kodi_userdata>/addon_data/plugin.video.themoviedb.helper/players/
   ```

2. Two player options available:
   - **AIOStreams** - Auto-plays first available stream
   - **AIOStreams (Select)** - Shows stream selection dialog

3. Use TMDBHelper to browse content, then select AIOStreams when prompted to play

For more details, see `tmdbhelper-players/README.md`

## Requirements

- Kodi 19 (Matrix) or later
- Internet connection
- Valid AIOStreams configuration

## API Structure

The addon uses the following AIOStreams endpoints:

- **Manifest**: `{BASE_URL}/manifest.json`
- **Search**: `{BASE_URL}/catalog/{type}/{catalog_id}/search={query}.json`
- **Streams**: `{BASE_URL}/stream/{type}/{id}.json`

## Notes

- Make sure your AIOStreams instance is accessible
- The base URL includes your authentication token
- Streams may require additional debrid services configured in AIOStreams

## Troubleshooting

**No results found:**
- Check your internet connection
- Verify the AIOStreams URL is correct
- Ensure AIOStreams is running and accessible

**Streams won't play:**
- Make sure you have debrid services configured in AIOStreams
- Check that the stream URL is accessible
- Some streams may require specific Kodi video addons or inputstream.adaptive

## License

MIT License

# Installation Instructions for AIOStreams Kodi Addon

## Quick Install

1. **Download the addon folder**
   - The complete addon is in the `plugin.video.aiostreams` folder

2. **Copy to Kodi addons directory**
   
   Depending on your platform, copy the entire `plugin.video.aiostreams` folder to:
   
   - **Windows**: `%APPDATA%\Kodi\addons\`
   - **Linux**: `~/.kodi/addons/`
   - **macOS**: `~/Library/Application Support/Kodi/addons/`
   - **Android**: `/sdcard/Android/data/org.xbmc.kodi/files/.kodi/addons/`

3. **Enable the addon**
   - Restart Kodi
   - Or go to: Settings → Addons → My addons → Video addons
   - Find "AIOStreams" and enable it

## Configuration

The addon comes pre-configured with your AIOStreams URL. If you need to change it:

1. Right-click on the addon icon
2. Select "Settings"
3. Update the "AIOStreams Base URL" if needed
4. Adjust timeout if experiencing slow connections

## First Use

1. Open the addon from Video Addons
2. Select "Search Movies" or "Search TV Shows"
3. Enter your search query
4. Select a result to see available streams
5. Click on a stream to play

## Troubleshooting

### No search results
- Check your internet connection
- Verify AIOStreams URL is correct and accessible
- Try increasing the timeout in settings

### Streams won't play
- Ensure you have debrid services configured in AIOStreams
- Some streams may require inputstream.adaptive addon
- Check Kodi logs for specific errors

### Addon won't install
- Make sure you're using Kodi 19 (Matrix) or later
- Verify the folder is named exactly `plugin.video.aiostreams`
- Check that all files are present in the folder

## Dependencies

The addon requires these Kodi modules (usually pre-installed):
- xbmc.python (3.0.0+)
- script.module.requests
- script.module.routing

## Support

If you encounter issues:
1. Check the Kodi log file
2. Verify your AIOStreams instance is running
3. Test the AIOStreams API directly in a browser

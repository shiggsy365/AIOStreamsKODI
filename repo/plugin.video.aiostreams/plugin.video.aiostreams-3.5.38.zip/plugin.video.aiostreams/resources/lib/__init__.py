# Resources lib module
